import wx
import thread
import threading
import socket
import sys
import os
import subprocess as sp
import traceback
import signal
import vlc
import time
from time import time, ctime
import math
import random


#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#StereoBim_server.py
#Contains 2 classes : Server and MainFrame (the GUI)

#Programm starts out by creating instance of MainFrame, which creates instance of Server
#User is then invited to enter a port, and a sound file.
#If these two conditions are OK, then it is possible to click on button Start

#MainFrame.btn_start calls Server.connectServer()
#If method succeeds, server is connected and ready to send the audio files. Server.runServer() is called.
#Server.runServer() is an infinite loop which waits for client.
#If a client connects, method Server.ClientManagement() is called.
#Server.ClientManagement() is called, which first calls Server.ClientArrival(), a method which sends the audio files to the client.
#Server.ClientManagement() then goes in an infinite loop which listens to the client and hears requests from the client, mostly those of the client wanting to leave. Appropriate methodes are then called

#MainFrame buttons Play, Pause and Stop call methods who are applied on the players, and sent to all clients so that their players do the same actions.
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$



######################################################################################################################################### 
#                                                              Class Server
##########################################################################################################################################

class Server(wx.Frame):

    # Initialisation method, called when the server frame opens. It creates the server object and enables the server frame to call the server's functions
    def __init__(self, parent, wxframe,fileInfoPath):
        
        print "Creating server instance."

        self.wxframe=wxframe
        self.port=self.wxframe.label_port.GetValue()
        self.stopBoolServ = False # signals that server is available
        self.socks = {} # will hold the clients' sockets
        self.clientsNames = {} # will hold the clients' names
        self.threads = {} # will hold the different threads
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM) # tcp socket for communicating with each client individually
        
        self.BLOCK_SIZE = 1024 # maximum size of the messages
        self.fileInfo = fileInfoPath # text file giving information regarding what file to use and how        
        print "fileInfoPath ",fileInfoPath
        self.filesPaths,self.pgPlayer = self.readAndConvert() # method will create the media player and new files if needed
        self.isPlaying = -1 # indicates if music has started through indices of currently playing files
        
    # Method called by mainFrame.onButtonstart.
    # Method which tries to create the sock.
    # The method can fail, especially if the port is already used because the programm was launched several times in a limited amount of time. That is why there is a try catch.
    # This method is called by pressing the power button on the server frame
    def connectServer(self):
        try:
            self.sock.bind(('',int(self.port)))
            self.sock.listen(5)
            return True
        except:
            print "Connection error"
            return False
        
    # Method called by mainFrame.onButtonstart.
    # Runs the infinite loop for the network. 
    # Listens for new clients to connect and starts corresponding threads.
    # New clients' associated threads, names and sockets are added to a dictionnary with their addresses as key.
    # Method called by Power button if connectServer has succeded
    def runServer(self):

        ## Creation of the server connection, TCP protocol, port binding, etc.
		
        # Start of the infinite loop.
        self.stopBoolServ = True
        print "Server is now available for client connection."
       
        while self.stopBoolServ:
            # Waiting for new clients to connect.
            newsock, addr = self.sock.accept()
            if self.stopBoolServ :
                #If a client arrives, then a thread is created, and ClientManagement is called
                thr = threading.Thread(target = self.clientManagement, args=(newsock,addr)) 
                thr.start() 

                self.threads[addr] = thr # add it to threads and socket dictionnary
                self.socks[addr] = newsock
                

        # Once stopBoolServ == False (when application closes), socket is closed.
        self.sock.shutdown(1)
        self.sock.close()
        print "Communications cut off."

    # Method called by mainFrame.onQuit.
    # For when server user wants to close the application.
    # Tells the clients that the application will stop and stops the player as well.
    # A final, fictive client socket is created to end the infinite loop in runServer().
    def serverClose(self):

        print "Closing application."

        if self.stopBoolServ==True: # if communication has already been enabled
            # Server tells every client to stop the application.
            for a in self.socks:
                self.socks[a].send("Play over!")
                self.socks[a].recv(self.BLOCK_SIZE) # client answers ok
            self.stopBoolServ = False # to end the infinite loop of runServer()

            # fictive socket to connect to the server since it is still waiting for a client to connect, even though stopBoolServ is now False
            sock_end = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock_end.connect(('127.0.0.1', int(self.port)))

            # Waiting for all threads to finish.
            for t in self.threads :
                self.threads[t].join()

            # Closing the fictive client.
            sock_end.shutdown(1)
            sock_end.close()
        else:
            print "Application closed before starting communication."
            self.sock.close()

        ## Player management.
        if self.isPlaying != -1:
            self.pgPlayer.stop()

        ## Deleting created files
        print "Previously generated files will now be deleted."
        for f in self.filesPaths:
            if(f.find("stereoRightchan")!=-1 or f.find("stereoLeftchan")!=-1 or f.find("extractedAudio")!=-1):
                try:
                    os.remove(f)
                except OSError:
                    print "No file to delete."
        if(self.fileInfo.find("generatedFileInfo")!=-1):
            os.remove(self.fileInfo)
        print "Files deletion complete."

        print "Application closed."

    # Method called by Server.__init__.
    # Read the options in self.fileInfo to direct the program behaviors.
    # If relevant, converts the original file to a supported codec, extract audio, etc. using ffmpeg.
    # Returns the path to the files that will be sent to the client, as well as the vlc MediaPlayer object that will be used to play the original file by the server.
    def readAndConvert(self):

        print "Analysing playing options."

        #=========================  Information reaping  ======================

        ## open the guiding file text
        fInfo = open(self.fileInfo,'r')

        ## get the informations written in the file and that will be used as guidelines for the following behavior of the application 
        options = fInfo.readline()[:-1].split(':') # what will be played (audio file or movie) and related information (stereo or other options, cf README.txt file)
        fPaths = fInfo.readline()[:-1].split(':') # absolute paths of the media files
        newFilesFormats = fInfo.readline()[:-1].split(':') # format to be used to reencode the files if relevant, "copy" if no reencoding is necessary 

        # generate the filenames
        initialFilesNames = [] # names of the files before conversion
        for p in fPaths:
            iName = (p.split('/'))[-1]
            initialFilesNames.append(iName)

        print "Playing options are ", options
        print "with file(s) ",initialFilesNames

        #==========================  Conversion  ===========================

        newFilesNames = [] # names of the reencoded files
        newFilesPaths = [] # paths of the reencoded files
        print "Now beginning reencoding."
        if options[0] == "music": # only audio files will be played
            if options[1] == "identical": # all clients will play the files in the exact same way

                ## Reencode the files according to demanded formats
                for i in range(len(newFilesFormats)):
                    if newFilesFormats[i] == "copy": # the file is already ready to be played, there is no need to reencode it
                        print "File " + initialFilesNames[i] + " was not converted."
                        newFilesNames.append(initialFilesNames[i])
                        newFilesPaths.append(fPaths[i])
            elif options[1] == "stereo": # music can be separated in right and left channels

                for i in range(len(newFilesFormats)):
                    if newFilesFormats[i] == "copy":
                        ## Adding the original file for the server to play.
                        print "File " + initialFilesNames[i] + " was not converted."
                        newFilesNames.append(initialFilesNames[i])
                        newFilesPaths.append(fPaths[i])
                        
                        ## Extract the two channels
                        nameLeft = "stereoLeftchan"+initialFilesNames[i]
                        pathLeft = "./"+nameLeft
                        nameRight = "stereoRightchan"+initialFilesNames[i]
                        pathRight = "./"+nameRight
                        
                        # Extraction using ffmpeg
                        print "Extracting stereo channels from ", initialFilesNames[i]
                        os.system("ffmpeg -i %s -map_channel 0.0.0 %s -map_channel 0.0.1 %s"%(fPaths[i],pathLeft,pathRight))
                        print "Extraction complete"

                        # Add them to the lists
                        newFilesNames.append(nameLeft)
                        newFilesNames.append(nameRight)
                        newFilesPaths.append(pathLeft)
                        newFilesPaths.append(pathRight)

        ## Coding for video file
        elif options[0] == "video":
            # Extract audio from video
            extractedAudio = []
            for f in range(len(fPaths)):
                extracted = "extractedAudio"+(initialFilesNames[f])[:-4]
                extractPath = "./"+extracted+".mp3"
                print "Extracting audio from ",initialFilesNames[f]
                os.system("ffmpeg -i %s -vn -ar 44100 -ac 2 -ab 192k -f mp3 %s"%(fPaths[f],extractPath))
                print "Extraction complete"
                extractedAudio.append(extractPath)

            # Then managing second option
            if options[1] == "identical": # all clients will play the files in the exact same way
                ## Reencode the files according to demanded formats
                for i in range(len(newFilesFormats)):
                    if newFilesFormats[i] == "copy": # the file is already ready to be played, there is no need to reencode it
                        print "File " + extractedAudio[i] + " was not converted."
                        newFilesNames.append((extractedAudio[i])[2:])
                        newFilesPaths.append(extractedAudio[i])
            elif options[1] == "stereo": # music can be separated in right and left channels
                for i in range(len(newFilesFormats)):
                    if newFilesFormats[i] == "copy":
                        ## Adding the original file for the server to play.
                        print "File " + extractedAudio[i] + " was not converted."
                        newFilesNames.append((extractedAudio[i])[2:])
                        newFilesPaths.append(extractedAudio[i])
                        
                        ## Extract the two channels
                        nameLeft = "stereoLeftchan"+((extractedAudio[i])[2:])
                        pathLeft = "./"+nameLeft
                        nameRight = "stereoRightchan"+((extractedAudio[i])[2:])
                        pathRight = "./"+nameRight
                        
                        # Extraction using ffmpeg
                        print "Extracting stereo channels from ", ((extractedAudio[i])[2:])
                        os.system("ffmpeg -i %s -map_channel 0.0.0 %s -map_channel 0.0.1 %s"%(extractedAudio[i],pathLeft,pathRight))
                        print "Extraction complete"

                        # Add them to the lists
                        newFilesNames.append(nameLeft)
                        newFilesNames.append(nameRight)
                        newFilesPaths.append(pathLeft)
                        newFilesPaths.append(pathRight)                

        print "Conversion complete, now on to player creation."


        #========================  Player creation  ===========================


        if options[0] == "video": # assuming that user only use compatible codecs, should be changed accordingly if not
                mediaList = [] # list holding all the vlc.Media instances corresponding to the files to be read
                for f in fPaths : 
                    media = vlc.Media(f)
                    mediaList.append(media)
                mediaLeftToRead = mediaList[:]
                mediaLeftToRead.pop(0)
                player = vlc.MediaPlayer()
                playerEventManager = player.event_manager()
                playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded,mediaList,mediaLeftToRead) # call mediaEnded(mediaList) every time a file reaches its end
                player.set_media(mediaList[0])
                print "Player now ready to play ", newFilesNames
        else:
            if options[1] == "identical":
                mediaList = [] # list holding all the vlc.Media instances corresponding to the files to be read
                for f in newFilesPaths : 
                    media = vlc.Media(f)
                    mediaList.append(media)
                mediaLeftToRead = mediaList[:] # list of the media that haven't been played yet
                mediaLeftToRead.pop(0)
                player = vlc.MediaPlayer()
                playerEventManager = player.event_manager()
                playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded,mediaList,mediaLeftToRead) # call mediaEnded(mediaList) every time a file reaches its end
                player.set_media(mediaList[0])
                print "Player now ready to play ", newFilesNames
            elif options[1] == "stereo":

                ## Get the original files
                original = [] # list of original, non channel-filtered audio files
                for p in newFilesPaths:
                    if(p.find("stereoLeftchan")==-1 and p.find("stereoRightchan")==-1):
                        original.append(p)

                ## Create the player and lists that will be used to read the next file when the previous is over.
                mediaList = [] # list holding all the vlc.Media instances corresponding to the files to be read
                for f in original : 
                    media = vlc.Media(f)
                    mediaList.append(media)
                mediaLeftToRead = mediaList[:] # list of the media that haven't been played yet
                mediaLeftToRead.pop(0)
                player = vlc.MediaPlayer()
                playerEventManager = player.event_manager()
                playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded,mediaList,mediaLeftToRead) # call mediaEnded(mediaList) every time a file reaches its end
                player.set_media(mediaList[0])
                print "Player now ready to play ", newFilesNames
        

        #=============================  Return  ===============================
        
        return newFilesPaths,player
                


############################################################################################################
#                                      CLIENT MANAGEMENT METHODS
############################################################################################################

    # Method called by Server.runServer.
    # Manages the regular communications between the client and the server, such as common resync and communication termination.
    # Every client is bound to this method through a thread.
    # This method starts off by calling clientArrival() 
    # It then runs an infinite loop listening to ponctual requests of the client. Requests are mostly requets from the client to leave the server.
    # It is called when a new client connects to the server,
    def clientManagement(self,sockClient, addr):

        # calling ClientArrival
        self.clientArrival(sockClient, addr) # manages the particular instructions to give when a client first connects.
        name = (self.clientsNames[addr])[0]
        print "Client ", name," has successfully joined."

        # Infinite loop.
        again = True
        while again :
            
            # listening to requests from the clients
            data = sockClient.recv(self.BLOCK_SIZE)
            print "Client ",name," sent a request:"
            if(data == "Ragequit"):
                print "Client ",name," is asking to leave."
                self.clientLeave(sockClient, addr)
                del self.threads[addr]
                again = False
            elif(data == "But the show should go on!"):
                again = False               
                print "Client ", name," is warned of application closure."
        print "Client ",name," has successfully disconnected"
    
    # Method called by Server.clientManagement.
    # Manages the first steps of communication with client by: 
    # - getting the client's name and inserting it in the GUI
    # - sending over the media files as well as the fileInfo file;
    # - indicating if playing has started and for how long;
    def clientArrival(self,sockClient, addr):
        
        print "Beginning client arrival procedure."

        # get the client's name
        sockClient.send("What's your name, Bob ?")
        nameclient=sockClient.recv(self.BLOCK_SIZE)
        self.clientsNames[addr] = [nameclient, len(self.clientsNames)]
        print nameclient," has arrived."
        
        # inserting the name in the client list of the GUI
        try:
            wx.MutexGuiEnter()
            self.wxframe.clientlist.InsertItems([self.clientsNames[addr][0]], self.clientsNames[addr][1])
            wx.MutexGuiLeave()
        except:
            print "Name could not be added."

        #===================== File transfer ===============

        ##  Indicate to the client that file transfer will now begin.
        sockClient.send("Ready for file transfer?")
        recv = sockClient.recv(self.BLOCK_SIZE)
        if(recv=="Beam them up!"):
            ## sending of the fileInfo and media files
            paths = (self.filesPaths)[:]
            paths.insert(0,self.fileInfo) # get all the paths in one list
            f = 0 # files counter
            print "Sending files to ", nameclient

            while f<(len(paths)) : # will send all converted files ready to use
                fileSize = os.path.getsize(paths[f]) # size of the file, will be used to determine if sending the file in more than one go is necessary
                
                ## send file name
                name = (paths[f].split('/'))[-1] # name without the absolute path
                sockClient.send("Here is a new file") # indicate a new file is going to be sent
                sockClient.recv(self.BLOCK_SIZE)
                sockClient.send(name)
                sockClient.recv(self.BLOCK_SIZE)
                
                ## begin file sending
                num = 0 # counter of bytes sent
                percent = 0 # transfer progression
                fileOp = open(paths[f],"rb")
                print "Sending ",paths[f]
                
                if(fileSize > self.BLOCK_SIZE):
                        ## send file by chunks of BLOCK_SIZE
                        for i in range(fileSize/self.BLOCK_SIZE):
                                fileOp.seek(num,0)
                                chunk = fileOp.read(self.BLOCK_SIZE)
                                sockClient.send(chunk) 
                                sockClient.recv(self.BLOCK_SIZE)
                                num = num + self.BLOCK_SIZE
                                
                                # print the progression of the transfer
                                if percent == 0 and num > fileSize / 100 * 10 and num < fileSize / 100 * 20:
                                        print " >> 10%"
                                        percent = 1
                                elif percent == 1 and num > fileSize / 100 * 20 and num < fileSize / 100 * 30:
                                        print " >> 20%"
                                        percent = 2
                                elif percent < 3 and num > fileSize / 100 * 30 and num < fileSize / 100 * 40:
                                        print " >> 30%"
                                        percent = 3
                                elif percent < 4 and num > fileSize / 100 * 40 and num < fileSize / 100 * 50:
                                        print " >> 40%"
                                        percent = 4
                                elif percent < 5 and num > fileSize / 100 * 50 and num < fileSize / 100 * 60:
                                        print " >> 50%"
                                        percent = 5
                                elif percent < 6 and num > fileSize / 100 * 60 and num < fileSize / 100 * 70:
                                        print " >> 60%"
                                        percent = 6
                                elif percent < 7 and num > fileSize / 100 * 70 and num < fileSize / 100 * 80:
                                        print " >> 70%"
                                        percent = 7
                                elif percent < 8 and num > fileSize / 100 * 80 and num < fileSize / 100 * 90:
                                        print " >> 80%"
                                        percent = 8
                                elif percent < 9 and num > fileSize / 100 * 90 and num < fileSize / 100 * 100:
                                        print " >> 90%"                    
                                        percent = 9
                                        
                else: # if file size is small enough
                        chunk = fileOp.read()
                        sockClient.send(chunk)
                        sockClient.recv(self.BLOCK_SIZE)
                                        
                ## end of file transfer
                fileOp.close()
                sockClient.send("file end")
                sockClient.recv(self.BLOCK_SIZE)
                print "File sent."
                f += 1 # increase of file counter to pursue transfering of the other files
            

            # signal all files were sent
            sockClient.send("Transfer complete")
            sockClient.recv(self.BLOCK_SIZE)
            print "Files transfer complete."
            

        #==================  Preparations for the client's player  ===============

        print "Sending current status."
        msg = sockClient.recv(self.BLOCK_SIZE)
        if msg == "Have you started playing?":
            if self.isPlaying>(-1): # if playing was previously started, even if currently paused (see start() method) 
                sockClient.send("I'm knockin' on Heaven's Door")
                sockClient.recv(self.BLOCK_SIZE) # client asks "Which file are you playing?"
                sockClient.send(str(self.isPlaying))
                sockClient.recv(self.BLOCK_SIZE) # client asks "How far are you?"
                temporarilyPaused = False # to know if playing was paused for the sake of the knew client arrival or not
                if self.pgPlayer.is_playing()==True: 
                    self.pauseResume()
                    temporarilyPaused = True
                else: sockClient.send("ready")
                current_time=self.pgPlayer.get_time() # time position in the media in ms
                sockClient.send(str(current_time))
                sockClient.recv(self.BLOCK_SIZE) # client says his preparations are complete
                if temporarilyPaused : self.pauseResume()
            else:
                sockClient.send("Still tuning")
                sockClient.recv(self.BLOCK_SIZE) # client says he'll wait

    # Method called by Server.clientManagement.
    # Manages the operations to run when a client disconnects.
    # For instance, it reaffects the client's tasks to another client if necessary.
    # Client's associated thread and socket are then deleted from the dictionnaries.
    # called when client asks for it, in clientManagement
    def clientLeave(self,sockClient, addr):
        try:
            ## Removing all client's information from lists and dictionnaries. 
            self.wxframe.clientlist.Delete(self.clientsNames[addr][1])
            index = self.clientsNames[addr][1]
            del self.clientsNames[addr]
            for i in self.clientsNames :
                if self.clientsNames[i][1] > index :
                    self.clientsNames[i][1] -= 1

        except:
            print "No client to delete." 

        ## Read fileInfo to know about options and what actions to take.
        fInfo = open(self.fileInfo,'r')
        options = fInfo.readline()[:-1].split(':')
        if options[1] == "identical" or options[1] == "stereo" :
            del self.socks[addr]
        sockClient.send("I shall give you your sock back") #Dobby approves
        sockClient.shutdown(1)
        sockClient.close()



############################################################################################################
#                                          PLAYING METHODS
############################################################################################################

    # Method called by mainFrame.onButtonPause and Server.clientArrival when the music has already started and is not paused.
    # Start, pause or resume playing by the server and clients according to current status.
    def pauseResume(self): 
	
        if self.isPlaying==-1:
            for s in self.socks :
				self.socks[s].send("Start playing")
            self.pgPlayer.play()
            self.isPlaying = 0
            while(self.pgPlayer.is_playing()==False): waiting =True
            timeHere = ctime(time()) 
            print "Now starting to play at "+ timeHere
        else:
            if self.pgPlayer.get_time() != -1:
                for s in self.socks:
                    self.socks[s].send("Pause")
                forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
                self.pgPlayer.pause()
                while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
                if self.pgPlayer.is_playing():
                    print "Music resumed."
                else:
                    print "Music paused."
            else:
                for s in self.socks:
                    self.socks[s].send("Pause")
                forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
                self.pgPlayer.play()
                while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
                print "Music resumed."

    # Method called by mainFrame.onButtonstop and mainFrame.onQuit.
    # Stop playing by the server and clients.
    def stop(self):
        for s in self.socks:
            self.socks[s].send("Stop")
        self.pgPlayer.stop()
        print "Music stopped."

    # Method called by events vlc.EventType.MediaPlayerEndReached.
    #Manages the events that happen when an audio or video track ends. 
    #The next file on the list is played right away. If the current file was the last on the list, nothing happens from the user's point of view.
    def mediaEnded(self,Event,mediaList,mediaLeftToRead):

        print "Media ended. The next on the playlist will now begin."

        # Find which media is currently loaded
        if len(mediaLeftToRead)==0:
            print "Playlist is empty."
            self.pgPlayer = (mediaList[0]).player_new_from_media()
            self.isPlaying = -1
            self.wxframe.timer.Stop()
            newMediaLeftToRead = mediaList[:]
            newMediaLeftToRead.pop(0)
            playerEventManager = self.pgPlayer.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded,mediaList,newMediaLeftToRead) # call mediaEnded(mediaList) every time a file reaches its end
        else:
            self.pgPlayer = mediaLeftToRead[0].player_new_from_media()
            mediaLeftToRead.pop(0)
            wx.MutexGuiEnter()
            self.wxframe.player.SetMin(0)
            self.wxframe.player.SetMax(self.pgPlayer.get_length())
            wx.MutexGuiLeave()
            forWaiting=self.pgPlayer.is_playing()
            self.pgPlayer.play()
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
            self.isPlaying += 1
            playerEventManager = self.pgPlayer.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded,mediaList,mediaLeftToRead) # call mediaEnded(mediaList) every time a file reaches its end
            print "Started playing next file."
                   

#=========================================================================================================================================
#                                                                    Class MainFrame
#=========================================================================================================================================


class MainFrame(wx.Frame):

    # init method which creates the frame and all of the elements on it (buttons, etc)
    # it also enables or disables some buttons to prevent the user from doing actions the programm cannot do (connect to a server without having a name for instance)
    # it also creates the server object
    # This is the method which is called when the programm is launched.
    def __init__(self, parent, ID, title, pos, size):
        wx.Frame.__init__(self,parent,ID, title, pos, size,style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        
        self.serverStarted=False #indicates if the server is started
        self.filesRoads = [] # paths toward the files that are going to be played. 
        self.filesnames = {} # names and index in the playlist of the files that are going to be played.
        self.nbrfiles = 0 # number of files that are going to be played.
        self.accepted_formats = []

        #Creation of positions
        w=size[0]
        h=size[1]

        leftside=w*0.02
        
        txt_host_x=0
        txt_host_y=0
        
        txt_port_x=w*0.37
        txt_port_y=0
        
        txt_soundmode_x=leftside+w*0.2
        txt_soundmode_y=h*0.14
        
        list_soundmode_x=txt_soundmode_x+95
        list_soundmode_y=txt_soundmode_y-5
        
        txt_path_x=list_soundmode_x+95
        txt_path_y=txt_soundmode_y
        
        btn_choose_x=txt_path_x+40
        btn_choose_y=txt_path_y-5
        btn_choose_w=60
        btn_choose_h=30
        
        btn_start_x=w*0.8
        btn_start_y=h*0.44
        btn_start_w=105
        btn_start_h=btn_start_w

        diode_x=btn_start_x
        diode_y=btn_start_y-40
        diode_w=btn_start_w
        diode_h=btn_start_h/3
        
        player_x=50
        player_y=h*0.80
        player_w=500
        player_h=50
        
        playlist_x=w*0.02
        playlist_y=h*0.32
        playlist_w=220
        playlist_h=152
        
        clientlist_x=playlist_x+playlist_w+leftside
        clientlist_y=playlist_y
        clientlist_w=playlist_w
        clientlist_h=playlist_h
        
        time_start_x=player_x-10
        time_start_y=player_y-10
        
        time_stop_x=player_x+476
        time_stop_y=player_y-10
        
        btn_play_x=player_x+150
        btn_play_y=player_y+30
        
        btn_stop_x=player_x+250
        btn_stop_y=player_y+30
        
        txt_playlist_x=playlist_x+75
        txt_playlist_y=playlist_y-20
        
        txt_clientlist_x=clientlist_x+75
        txt_clientlist_y=clientlist_y-20
        
        label_port_x=txt_port_x+45
        label_port_y=txt_port_y
        label_port_w=50
        label_port_h=25
        
        txt_port2_x=label_port_x+60
        txt_port2_y=label_port_y

        btn_delete_x = btn_choose_x + 80
        btn_delete_y = btn_choose_y
        btn_delete_w = 80
        btn_delete_h = 30
        
        #Creation of graphical elements
        image1 = wx.Image("start_im.jpg", wx.BITMAP_TYPE_ANY).ConvertToBitmap()
        self.btn_start = wx.BitmapButton(self, id=-1, bitmap=image1, pos=(btn_start_x, btn_start_y), size = (btn_start_w,btn_start_h)) 
        self.txt_host=wx.StaticText(self,2,"IP Adress : " + socket.gethostbyname(socket.getfqdn()),(txt_host_x,0))
        self.txt_port=wx.StaticText(self,2,"Port : ",(txt_port_x,txt_port_y))
        self.txt_soundmode=wx.StaticText(self,2,"Sound Mode :", (txt_soundmode_x,txt_soundmode_y))
        self.txt_path=wx.StaticText(self,2,"Path : ",(txt_path_x,txt_path_y))
        self.list_soundmode = wx.Choice(self, -1, (list_soundmode_x,list_soundmode_y), choices=['mono','stereo'])
        self.btn_choose=wx.Button(self,2, "...",(btn_choose_x,btn_choose_y),(btn_choose_w,btn_choose_h))
        self.player=wx.Slider(self,2,0,0,100,(player_x,player_y),(player_w,player_h))
        self.playlist=wx.ListBox(self, 2,(playlist_x,playlist_y),(playlist_w,playlist_h))
        self.clientlist=wx.ListBox(self,2,(clientlist_x,clientlist_y),(clientlist_w,clientlist_h))
        self.time_start=wx.StaticText(self,2,"00:00",(time_start_x,time_start_y))
        self.time_stop=wx.StaticText(self,2,"00:00",(time_stop_x,time_stop_y))
        self.btn_play=wx.Button(self,2,"Play/Pause",(btn_play_x,btn_play_y))
        self.btn_stop=wx.Button(self,2,"Stop",(btn_stop_x,btn_stop_y))
        self.txt_playlist=wx.StaticText(self,2,"Playlist",(txt_playlist_x,txt_playlist_y))
        self.txt_clientlist=wx.StaticText(self,2,"Client list",(txt_clientlist_x,txt_clientlist_y))
        self.label_port=wx.TextCtrl(self,2,"8000",(label_port_x,label_port_y),(label_port_w,label_port_h))
        self.txt_port2=wx.StaticText(self,2,"(recommended between 6000 and 8000)",(txt_port2_x,txt_port2_y))
        self.diode=wx.ListBox(self,ID,(diode_x,diode_y),(diode_w,diode_h))
        self.btn_delete = wx.Button(self, 2, "Delete", (btn_delete_x, btn_delete_y), (btn_delete_w, btn_delete_h))

        self.timer=wx.Timer(self)
        self.SetAutoLayout(True)

        #Binding of elements and methods
        self.btn_choose.Bind(wx.EVT_BUTTON, self.DoOpenFile)
        self.btn_start.Bind(wx.EVT_BUTTON, self.onButtonstart)
        self.btn_play.Bind(wx.EVT_BUTTON, self.onButtonPause)
        self.btn_stop.Bind(wx.EVT_BUTTON, self.onButtonStop)     
        self.Bind(wx.EVT_CLOSE, self.onQuit)
        self.Bind(wx.EVT_TIMER,self.on_timer,self.timer)
        self.Bind(wx.EVT_BUTTON, self.DeleteFile)
        
        #Definition of colors       
        background_coulour='#75C8FF'
        field_coulour='#D6EFFF'
        bouton_coulour='##FFD633'
        self.diode_coulour_connected='#006600'
        self.diode_coulour_disconnected='#666699'
        self.SetBackgroundColour(background_coulour)
        self.diode.SetBackgroundColour(self.diode_coulour_disconnected)
        
        #Diasbling certain buttons
        self.btn_play.Enable(False)
        self.btn_stop.Enable(False)
        self.btn_start.Enable(False)
        self.btn_delete.Enable(False)

    # Method called when the corresponding button is pressed.
    # This method tries to connect the server.
    # It checks if there is a port number entered, if it is valid, and if a sound file is imported
    # If these conditions are OK, then a thread is launched which calls runServer()
    # If not, a message box appears, inviting the user to try another port
    def onButtonstart(self,evt):

        #checking
        if self.filesRoads != [] and self.label_port.GetValue() != None :
            self.generateFileInfo()
            self.SER=Server(None,self,"./generatedFileInfo.txt")
            self.serverStarted=True
            
            #checking if the port is valid
            didyouconnectwiththisport=self.SER.connectServer()

            if didyouconnectwiththisport:

                #thread launching
                thrrun = threading.Thread(target = self.SER.runServer, args=())
                thrrun.start()
                self.diode.SetBackgroundColour(self.diode_coulour_connected)
                self.btn_play.Enable(True)
                self.label_port.Enable(False)
                self.btn_start.Enable(False)
                self.btn_stop.Enable(True)
                self.btn_choose.Enable(False)
                self.list_soundmode.Enable(False)
                self.btn_delete.Enable(False)

            else:
                wx.MessageBox('Impossible de lancer le serveur.. \n L\'erreur la plus probable est que le port est deja utilise. Veuillez changer le port et en avant la musique !','Impossible de creer le serveur',wx.OK | wx.ICON_INFORMATION) 

    # Method called when the corresponding button is pressed.
    # Call for the pauseResume() server method that makes everyone pause or resume playing.
    def onButtonPause(self, evt) :

        self.SER.pauseResume()
        if self.SER.pgPlayer.is_playing():
            self.player.SetMin(0)
            self.player.SetMax(self.SER.pgPlayer.get_length())
            self.timer.Start(500)
        else :
            self.timer.Stop()

    # Method called when the corresponding button is pressed.
    # Call for the stop() server method that makes everyone stop playing.        
    def onButtonStop(self,evt) :
		       
		self.SER.stop()
                self.timer.Stop()
                self.stopSlider()

    # Method called when the corresponding button is pressed.
    # Closes both server and frame.
    def onQuit(self, evt) :
        print "Closing application"
        if self.serverStarted==False:
            self.Destroy()
        else :
            self.timer.Stop()
            self.SER.serverClose()
            self.Destroy()

    # Method called when the corresponding button is pressed.
    # Method for opening files from the browser and importing them in the playlist
    # it can manage importing multiple files at a time
    # it also checks if the files have an extension which is readable by VLC.
    # if some files are not in this case, they are not added to the playlist and an information message appears
    def DoOpenFile(self,evt):

        #File reaping

        wcd = 'All files (*)|*|Editor files (*.ef)|*.ef|'
        dir = os.getcwd()
        open_dlg = wx.FileDialog(self, message='Choose a file', defaultDir=dir, defaultFile='',
                                 wildcard=wcd, style=wx.OPEN|wx.CHANGE_DIR|wx.FD_MULTIPLE)
        if open_dlg.ShowModal() == wx.ID_OK:

            road = str(open_dlg.GetPaths()) # is of the form

            road=road[3:len(road)] # remove the initial "[u
            road=road.split("', u'") # actually separate the all the paths
            road[len(road)-1]=road[len(road)-1][0:len(road[len(road)-1])-2] # remove the remaining ]" that was left in the last path

            filenames=str(open_dlg.GetFilenames())
            filenames=filenames[3:len(filenames)-1]
            filenames=filenames.split("', u'")
            filenames[len(filenames)-1]=filenames[len(filenames)-1][0:len(filenames[len(filenames)-1])-1]

            # Format verifying

            if self.accepted_formats == [] :
                i = 0
                while True :
                    extension = ((road[i]).split('.'))[-1]
                    if extension in ["wav","ogg","mp3"] :
                        self.accepted_formats = ["wav","ogg","mp3"]
                        break
                    elif extension in ["wmw","flv","mp4","avi"] :
                        self.accepted_formats = ["wmw","flv","mp4","avi"]
                        break
            print "accepted formats ", self.accepted_formats

            wrong_roads = []
            for i in road :
                extension = i.split(".").pop()
                if extension not in self.accepted_formats :
                    wrong_roads.append(i)
            for i in wrong_roads :
                road.remove(i)

            files_with_wrong_format=[]
            i_removed_some_files=False
            for i in filenames:
                try:
                    extension=i.split(".")[1]
                    if extension not in self.accepted_formats :
                        print "Formats non acceptable !"
                        files_with_wrong_format.append(i)
                except: 
                    print "L'extension n'a pas pu etre trouvee."
                    files_with_wrong_format.append(i)
               
            for i in files_with_wrong_format:
                i_removed_some_files=True
                filenames.remove(i)

            if i_removed_some_files==True:
                wx.MessageBox('Certains fichiers n\'avaient pas un format lisible par cette application. Seuls les fichiers a format lisible ont ete ajoutes. \n Les formats acceptes sont : \n pour l\'audio : .wav, .mp3, .ogg \n pour la video : .wmv, .flv, .mp4, .avi', 'Impossible d\'ouvrir tous les fichiers',wx.OK | wx.ICON_INFORMATION) 
                
            for way in road : self.filesRoads.append(way)
            print "filesRoads ",self.filesRoads	

            try:
                adjust_nbrfiles = 0
                for i in range(len(filenames)) :
                    if self.filesnames.has_key(filenames[i]) :
                        self.filesnames[filenames[i]].append(i + self.nbrfiles)
                        adjust_nbrfiles += 1
                    else :
                        self.filesnames[filenames[i]] = [i + self.nbrfiles]
                        adjust_nbrfiles += 1
                    self.playlist.InsertItems([filenames[i]], (i + self.nbrfiles))
                self.nbrfiles = self.nbrfiles + adjust_nbrfiles
                if (len(filenames)>0):
                    self.btn_start.Enable(True)
                    self.btn_delete.Enable(True)

            except IOError, error:
                dlg = wx.MessageDialog(self, 'Error opening file\n' + str(error))
                dlg.ShowModal()
                
            except UnicodeDecodeError, error:
                dlg = wx.MessageDialog(self, 'Error opening file\n' + str(error))
                dlg.ShowModal()
                
        open_dlg.Destroy()

    # Method called when the corresponding button is pressed.
    # Method to delete a file from the playlist
    def DeleteFile(self, evt) :
        pos = self.playlist.GetSelection()
        if pos >= 0 :
            self.playlist.Delete(pos)
            for name in self.filesnames :
                for i in range(len(self.filesnames[name])) :
                    if self.filesnames[name][i] == pos :
                        name_to_delete = name
                        index_to_delete = i
                    elif self.filesnames[name][i] > pos :
                        self.filesnames[name][i] -= 1
            if len(self.filesnames[name_to_delete]) == 1 :
                del self.filesnames[name_to_delete]
            else : 
                self.filesnames[name_to_delete].pop(index_to_delete)
            self.nbrfiles -= 1
            for road in self.filesRoads :
                name = road.split("/").pop()
                if name == name_to_delete :
                    self.filesRoads.remove(road)
                    break
            print "File deleted from the playlist."
            if(len(self.filesnames)==0):
				self.btn_delete.Enable(False)
				self.btn_start.Enable(False)
       
    # Method called by mainFrame.onButtonstart.
    # This is an inner method of the programm, which translates information inputed by the user to a fileInfo which the programm will then read
    def generateFileInfo(self):
        """
        Automatically creates the fileInfo according to user-selected options.
        """
        
        print "Creating relevant fileInfo."

        ## Determine if reading will be audio or video
        extension = ((self.filesRoads[0]).split('.'))[-1]
        if(extension == "mp4" or extension == "wmv" or extension == "avi" or extension == "flv"):
            fileType = "video"
        else:
            fileType = "music"
            
        ## Get selected options
        if(self.list_soundmode.GetSelection()==0):
            soundMode = "identical"
        else:
            soundMode = "stereo"

        ## Write the fileInfo
        generatedFileInfo = open("./generatedFileInfo.txt","w")
        generatedFileInfo.write(fileType + ':' + soundMode + '\n')
        for p in range(len(self.filesRoads)-1):
            generatedFileInfo.write(self.filesRoads[p]+':')
        generatedFileInfo.write(self.filesRoads[-1]+'\n')
        for i in range(len(self.filesRoads)-1):
            generatedFileInfo.write("copy:")
        generatedFileInfo.write("copy\n")
        generatedFileInfo.close()

    # Method called while the music is playing.
    def on_timer(self,timer):
        self.player.SetMin(0)
        self.player.SetMax(self.SER.pgPlayer.get_length())
        self.player.SetValue(self.SER.pgPlayer.get_time())
        current_time_s=self.SER.pgPlayer.get_time()/1000
        remaining_secs_i=current_time_s%60
        minutes_i=(current_time_s-remaining_secs_i)/60
        convert_time_i=str(minutes_i)+":"+str(remaining_secs_i)
        self.time_start.SetLabel(convert_time_i)
        total_time_s=self.SER.pgPlayer.get_length()/1000
        remaining_secs_f=total_time_s%60
        minutes_f=(total_time_s-remaining_secs_f)/60
        convert_time_f=str(minutes_f) + ":" + str(remaining_secs_f)
        self.time_stop.SetLabel(convert_time_f)

    # Method called by mainFrame.onButtonstop and mainFrame.onQuit.
    def stopSlider(self):
        self.player.SetValue(0)
        self.time_start.SetLabel("00:00")

######################################################################################################################################### 
#                                                              Class Main
##########################################################################################################################################


if __name__=="__main__":
	xpos=10
	ypos=40
	size_h=350
	size_w=600
	app = wx.App()
	app.TopWindow = MainFrame(None,2,"Stereo BIM - server",(xpos,ypos),(size_w,size_h))
	app.TopWindow.Show()
	app.MainLoop()

