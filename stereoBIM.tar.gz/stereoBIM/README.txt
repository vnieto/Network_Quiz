stereoBIM est une application permettant à un certain nombre d'utilisateurs, les clients, de jouer simultanément une ou plusieurs pistes audio fournies par un utilisateur particulier, désigné comme le serveur.


COMPOSANTES NECESSAIRES

Afin que l'application s'exécute sans accroc, il est nécessaire que tous les utilisateurs aient préalablement installé :
	(pour tous)
		- Python 2.7 et la bibliothèque wxPython
		- le lecteur multimedia VLC media player
	(pour le serveur)
		- le programme ffmpeg ainsi que toute bibliothèque de codecs qui pourrait être nécessaire pour l'utilisation du programme (en particulier en vue d'extraire l'audio de vidéos, de lectures en stereo ou de manipuler des formats multimedia peu courants) 

Attention, le programme a été développé sous Linux, aussi son efficacité sous Windows ou MacOS n'est pas garantie (sous Linux non plus d'ailleurs...)


UTILISATION PAR UN CLIENT

Lancer le client dans un terminal avec la commande
	python stereoBIM_client.py
Indiquer dans les champs correspondants l'adresse IP du serveur et son port dédié à l'application, ainsi que l'identifiant qui sera utilisé pour se différencier des autres clients auprès du serveur.
Cliquer sur le bouton "Connect". Le client tentera alors de se connecter avec les informations que vous avez fourni. Si les informations rentrées ne permettent pas une connexion (soit car le serveur n'est pas actif, soit car il y a une erreur dans les informations rentrées), un message s'affichera. Corriger et réessayer, jusqu'à ce que la connexion soit établie.
Lorsque la connexion est établie, le transfert des fichiers se lance. Selon le mode de lecture défini par le serveur, différentes informations supplémentaires pourront être demandées (par exemple si le client se trouve "à gauche" ou "à droite" lorsque la lecture est en mode stéréo).

Une fois les étapes de préparation effectuées, le client n'a plus qu'à attendre le lancement de la lecture par le serveur.
Dans le cas où la lecture aurait déjà été lancée par le serveur avant que le client ne se connecte, la lecture par le client commencera automatiquement, à la position courante du serveur.

Le client peut ensuite désirer rompre la connexion avec le serveur. Dans ce cas, cliquer sur le bouton "Disconnect". Ceci coupe la communication avec le serveur mais ne quitte pas l'application client. Le client revient simplement dans son état initial, en attente de connexion. Il est ensuite possible de se reconnecter au même serveur ou à un autre. 

Cliquer sur l'icône de fermeture de la fenêtre pour fermer complètement l'application (la déconnexion est alors automatique). Dans les deux cas, tous les fichiers qui avaient été reçus du serveur seront automatiquement supprimés.


Afin d'éviter tout risque de malentendu dans la communication client-serveur, nous recommandons d'éviter de rompre la connexion avec le serveur pendant le processus de transfert de fichiers. De plus, nous déconseillons la déconnexion/reconnexion intempestive d'un client afin d'éviter toute erreur.



UTILISATION PAR LE SERVEUR

L'utilisation du serveur se fait en deux temps : la mise en place du réseau et la lecture à proprement parler.

	Mise en place :
		Lancer l'application avec la commande
			python stereoBIM_server.py
		Modifier (si nécessaire) le numéro de port à utiliser pour l'application. 
		Sélectionner les différentes informations nécessaires : mode de lecture identique (tous les clients jouent exactement la même piste) ou stéréo (les clients jouent de manière cohérente le channel "gauche" ou "droit") ; fichiers à lire.
		A noter qu'il n'est pas possible actuellement de lire à la fois des fichiers audios et vidéos dans la même playlist.
		De plus, l'usage de ffmpeg pour l'extraction de l'audio des vidéos et des channels pour le mode stereo nécessite que le chemin absolu des fichiers ne contienne pas de caractères spéciaux. Et si les fichiers "extraits" existent déjà (n'auraient pas été effacé lors d'un bug précédent par exemple), ffmpeg demandera leur écrasement depuis le terminal.
		
		Une fois toutes les informations rentrées, cliquer sur le bouton marqué d'une icône "Power". Le serveur est rendu visible sur le réseau et ouvert aux connexions par les clients.

	Lecture : 
		Une fois le serveur en ligne, les clients peuvent se connecter quand ils le désirent. Une liste des clients connectés se trouve dans le champ "Client List".
		La mise en route et l'arrêt de la lecture sont cependant indépendants des connexions et déconnexions des clients. Il est permis à l'utilisateur de lancer ou d'arrêter la lecture en cliquant sur les boutons "Play/pause" ou "Stop", sans que cela n'entrave en aucune façon les communications clients-serveur.

	A noter que lorsque l'application est fermée à l'aide du bouton de fermeture de la fenêtre graphique, un message d'arrêt est envoyé à tous les clients, et les fichiers créés lors du processus de préparation sont automatiquement supprimés. 
