import wx
import thread
import threading
import socket
import sys
import os
import subprocess as sp
import vlc
import time
import math
import random

#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
#StereoBim_client.py
#Contains 2 classes : Client and MainFrame, which is the GUI.

#Programm starts out by creating instance of MainFrame, which instantly creates an instance of Client
#User is then invited to enter a client name, and a server IP and port

#MainFrame.btn_connect calls Client.connectToServer()
#If this method succeeds, the client is now connected to a server and Client.runClient() is called in a thread
#Client.runClient() is an infinite loop which listens to instructions from the server
#According to server instructions, Client.runClient() then calls diverse methods which can mainly play, pause and stop the sound files, and.
#If MainFrame.btn_end or MainFrame.EXIT_BTN is pressed, then Client.runClient() calls Client.departure() which handles the deconnection of the client from the server.
#$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


#=========================================================================================================================================
#                                                                    Class Client
#=========================================================================================================================================

class Client(wx.Frame):

    #Initialisation method, called when the client frame opens. It creates the client object and enables the client frame to call the client's functions
    def __init__(self, parent,wxframe): 

		self.wxframe=wxframe
		self.connected = False #to monitor connexion and maintain the loop
		self.BLOCK_SIZE = 1024
		self.filesPaths = [] # ist of files sent by the server
		self.offset = 0 # difference with time of start of server when client joins after playing has started
		self.isPlaying = False # indicates if player has already started playing, regardless of whether it is currently paused or not.
                self.mediaList = [] # list dictionnary holding all the vlc.Media instances corresponding to the files to be read
                self.mediaLeftToRead = [] # list of the media that haven't be played yet

    #Method to connect to the server, given a port and IP adress. The try/catch prevents the programm from crashing if the connection fails, and merely invites the user to try again
    #It is called by the frame button "Connect"
    def connectionToServer(self,ip,port):
        self.sockServer = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        
        try:
            self.sockServer.connect((ip,int(port)))
            self.connected = True
            print "Connection complete."
            
        except:
            print "Connection failed!"
            return False
        return True


    #This is the client's main method, where the infinite loop is called. In this loop, the client will constantly be listening to the server and waiting for any instruction the server will send.
    #It is called by frame button "Connect" after connectionToServer has returned True
    #and calls all the others methods of Client accordingly
    def runClient(self) :

        #The first instruction is to ask for the client's name
        nameclient=self.sockServer.recv(self.BLOCK_SIZE)
        if nameclient=="What's your name, Bob ?":
            self.sockServer.send(self.wxframe.myname)

        try :
                
            #==================================  Reception  ========================================
            
            #infinite loop
            while self.connected :
                
                #waiting for message from the server
                message = self.sockServer.recv(self.BLOCK_SIZE)

                if message == "Ready for file transfer?": # starts the loading of the audio files
                    self.filesReception()
                    self.pgPlayer = self.createPlayer() # creates the audio player according to options and server instructions
                    self.readyPlayer() # acts accordingly to the current activity of the server

                elif message =="Start playing": # starts to play at the beginning of the audio files
                    self.clientStart(False)
                    wx.MutexGuiEnter()
                    self.wxframe.timer.Start(500) # for progression bar
                    wx.MutexGuiLeave()
                elif(message == "Pause" or message == "Resume"): # pauses or resumes the playing
                    self.clientPlayPause(message)
                elif(message == "Play over" or message.find("Play over")!=-1): # finishes the playing and deletes the files
                    self.departure(False)
                elif(message == "Stop"):
                    self.pgPlayer.stop()
                    wx.MutexGuiEnter()
                    self.wxframe.timer.Stop()
                    self.wxframe.slider.SetValue(0)
                    self.wxframe.time_start.SetLabel("00:00")
                    self.wxframe.time_stop.SetLabel("00:00")
                    wx.MutexGuiLeave()
                    self.isPlaying = False
                    print "Music stopped."

            # Cut off communications with the server
            
            print "Disconnected from server" # the effective disconnection will happen just after (out of the try)
        
        except :
        
            print "Connection was broken."
            self.departure(True)
        
        #=======================================  End  =============================================================

        self.sockServer.shutdown(1)
        self.sockServer.close()


    #Receive fileInfo and media files from server.
    #Download all the files that will be played.
    #Called by runClient.
    def filesReception(self):

        transferComplete = False # to spot the end of the transfer
        self.sockServer.send("Beam them up!") # signal to the server that we are ready
        print "Beginning files transfer."
        while transferComplete == False: # ...transfering
            message = self.sockServer.recv(self.BLOCK_SIZE)
            if message == "Here is a new file": # first part of a new file, creation of the temporary audio file for the client
                print message
                self.sockServer.send("ok1") # tell the server that it can send the name of the file
                name = self.sockServer.recv(self.BLOCK_SIZE) # receive the name of the file
                path = "./client"+name
                self.filesPaths.append(path) # add the path to the list for future playing
                fileOp = open(path,"wb") # create a new local file to save the downloaded file
                self.sockServer.send("ok2") # tell the server it can start to send the audio file
            elif message == "file end": # last part of the file, closing of the audio file
                fileOp.close() # close and save the audio file
                print "File received."
                self.sockServer.send("ok3") # tell the server it can send another file or end the transfer
            elif message == "Transfer complete": # all the files have been transfered
                transferComplete = True
                print "Transfer complete. "
            else : 
                fileOp.write(message) # saving of the audio file into the fileOp
                self.sockServer.send("line received")
        self.sockServer.send("Sortie filesReception")
        print "All files successfully received."

    #Called by runClient in case of any communication rupture with the server, willingly (asked by the user) or not (any kind of bug which stops communication)
    #Manages preparations for communication rupture with the server.
    #Tasks such as deleting file and indicating what role this client had when necessary should be done here.
    #Command to end the main loop of the method runClient.
    def departure(self,willingly):

        # Stop the mediaPlayer if it was playing
        if self.isPlaying==True:
            self.pgPlayer.stop()
            self.isPlaying = False
            self.wxframe.timer.Stop()
        # willingly is a boolean indicating if communication rupture was asked by user (True) or the server (False).
        if willingly==False:
            self.sockServer.send("But the show should go on!") # tell the server that client will stop       
            print "Server asked for the communications to stop"
        elif(willingly==True and self.connected==True):
            fInfo = open(self.filesPaths[0],'r')
            options = fInfo.readline()[:-1].split(':')

            if options[1]=="identical" or options[1]=="stereo":
                print "Requesting parting from the server"
                self.sockServer.send("Ragequit") # tell the server that client wants to close the connection
                self.sockServer.recv(self.BLOCK_SIZE) # clientLeave from project_serveur.py has been called

        # Manage received files
        if self.connected==True:
            # Delete the downloaded, now useless files
            for f in self.filesPaths:
                try:
                    os.remove(f)
                except OSError:
                    print "File has already been removed."
            self.filesPaths = []
            self.mediaPaths = []
            print "Files successfully deleted."
        else :
            print "No files to delete."
        
        self.connected = False #ends RunClient infinite loop


    def createPlayer(self):
        """
        Create a vlc media player object to read the relevant file.
        """

        # open fileInfo file and get the options
        fInfo = open(self.filesPaths[0],'r')
        options = fInfo.readline()[:-1].split(':')

        # Create the audio player according to those options
        if options[1] == "identical":
            for f in self.filesPaths[1:] : 
                media = vlc.Media(f)
                self.mediaList.append(media)
            self.mediaLeftToRead = self.mediaList[:]
            self.mediaLeftToRead.pop(0)
            player = vlc.MediaPlayer()
            playerEventManager = player.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded) # call mediaEnded(mediaList) every time a file reaches its end
            player.set_media(self.mediaList[0])
            print "Player now ready to play."
        elif options[1] == "stereo":

            ## Find out on which side client is
            print "Are you on the Right or the Left? "
            side_understood=False
            while side_understood==False:
                side = raw_input()
                if side=="Right" or side=="right" or side=="R" or side=="r":
                    side="Right"
                    side_understood=True
                elif side=="Left" or side=="left" or side=="L" or side=="l":
                    side="Left"
                    side_understood=True
                if side_understood==False:
                    print "We did not manage to understand where you are. Please try again :"
            
            prefix= "stereo%schan"%side
            print "side and prefix ",side,prefix
            
            

            ## Select the relevant files
            sidePaths = []
            for i in range(1,len(self.filesPaths)):
                if self.filesPaths[i].find(prefix)!=(-1):
                    sidePaths.append(self.filesPaths[i])

            ## Create the player and lists that will be used to read the next file when the previous is over.
            for f in sidePaths : 
                media = vlc.Media(f)
                self.mediaList.append(media)
            self.mediaLeftToRead = self.mediaList[:]
            self.mediaLeftToRead.pop(0)
            player = vlc.MediaPlayer()
            playerEventManager = player.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded) # call mediaEnded(mediaList) every time a file reaches its end
            player.set_media(self.mediaList[0])

        print "Player created."

        return player

    #Verifies if the music should have started already or not and acts consequently.
    #If the music has already begun, starts to play and calls clientStart.
    #Else waits for the start (in method runClient).
    def readyPlayer(self):
        print "Preparations for the player."

        # Verify if playing has started by asking server
        self.sockServer.send("Have you started playing?")
        alreadyStarted = self.sockServer.recv(self.BLOCK_SIZE)
        
        if alreadyStarted=="I'm knockin' on Heaven's Door":
            self.clientStart(True) # if the music has already started, starts playing. The synchronisation will be made in clientStart
        else:
            self.offset = 0
            self.sockServer.send("Ok I'll wait")
            print "Player is now ready."

    #Starts the player.
    #According to whether the server had already begun playing or not, the player will start at the relevant position in the file.
    #ongoing is a boolean indicating whether the server has already started playing (True) or not (False).
    def clientStart(self,ongoing):

        print "Will now start playing." 

        if ongoing == False : # if everyone is now starting playing
            forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
            self.pgPlayer.play()
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
        else : # if everyone has already been playing for a while now

            self.sockServer.send("Which file are you playing?")
            toBePlayedIndex = int(self.sockServer.recv(self.BLOCK_SIZE))
            self.pgPlayer = (self.mediaList[toBePlayedIndex]).player_new_from_media()
            self.mediaLeftToRead = self.mediaList[(toBePlayedIndex+1):]
            playerEventManager = self.pgPlayer.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded) # call mediaEnded(mediaList) every time a file reaches its end
            self.sockServer.send("How far are you?")
            status = self.sockServer.recv(self.BLOCK_SIZE) # server method pauseResume() is called and sends "Pause" to all clients if playing, or "ready" to only this client
            print " "
            self.offset = int(self.sockServer.recv(self.BLOCK_SIZE)) # for how long has the server been playing
            print "offset: ",self.offset
            wx.MutexGuiEnter()
            self.wxframe.timer.Start(500)
            wx.MutexGuiLeave()
            forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
            self.pgPlayer.play() # position cannot be set unless play() has been called
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
            self.pgPlayer.pause()
            while(self.pgPlayer.is_playing() != forWaiting) : waiting = True # wait for player status to change
            if self.offset>-1: self.pgPlayer.set_time(self.offset) # start playing at that position
            self.sockServer.send("Let's party!")

        self.isPlaying = True

    #Runs or stops the player according to its current activity.
    def clientPlayPause(self,order) :
        self.isPlaying = True
        if self.pgPlayer.get_time()==-1:
            forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
            self.pgPlayer.play()
            wx.MutexGuiEnter()
            self.wxframe.timer.Start(500)
            wx.MutexGuiLeave()
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
            print "Music resumed."
        else:
            forWaiting = self.pgPlayer.is_playing() # will be used for to wait for player to actually change
            self.pgPlayer.pause()
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
            if self.pgPlayer.is_playing():
                print "Music resumed."
            else:
                print "Music paused."

    
        #Manages the events that happen when an audio or video track ends. 
        #The next file on the list is played right away. If the current file was the last on the list, nothing happens from the user's point of view.
    def mediaEnded(self,Event):
        print "Media ended. The next on the playlist will now begin."

        # Find which media is currently loaded
        if len(self.mediaLeftToRead)==0:
            print "Playlist is empty."
            self.wxframe.slider.SetValue(0)
            self.wxframe.time_start.SetLabel("00:00")
            self.wxframe.time_stop.SetLabel("00:00")
            self.pgPlayer = (self.mediaList[0]).player_new_from_media()
            self.isPlaying = False
            self.wxframe.timer.Stop()
            self.mediaLeftToRead = self.mediaList[:]
            self.mediaLeftToRead.pop(0)
            playerEventManager = self.pgPlayer.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded) # call mediaEnded(mediaList) every time a file reaches its end
        else:
            self.pgPlayer = self.mediaLeftToRead[0].player_new_from_media()
            self.mediaLeftToRead.pop(0)
            wx.MutexGuiEnter()
            self.wxframe.slider.SetMin(0)
            self.wxframe.slider.SetMax(self.pgPlayer.get_length())
            wx.MutexGuiLeave()
            forWaiting=self.pgPlayer.is_playing()
            self.pgPlayer.play()
            while(self.pgPlayer.is_playing() == forWaiting) : waiting = True # wait for player status to change
            playerEventManager = self.pgPlayer.event_manager()
            playerEventManager.event_attach(vlc.EventType.MediaPlayerEndReached,self.mediaEnded) # call mediaEnded(mediaList) every time a file reaches its end
            print "Started playing next file."


#=========================================================================================================================================
#                                                                    Class MainFrame
#=========================================================================================================================================

#This is the class for the window which appears and enables the user to use the programm.
class MainFrame(wx.Frame):

    #init method which creates the frame and all of the elements on it (buttons, etc)
    #it also enables or disables some buttons to prevent the user from doing actions the programm cannot do (connect to a server without having a name for instance)
    #it also creates the client object
    #This is the method which is called when the programm is launched.
    def __init__(self, parent,ID,title,pos,size):

        #window creation
        wx.Frame.__init__(self, parent,ID,title,pos,size,style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        
        #creation of positions and sizes for the window's elements
        w=size[0]
        h=size[1]
        
        leftside=w*0.02
        rightside=leftside
        topside=h*0.1
        
        x_name=leftside
        y_name=topside
        w_name=w*0.45
        h_name=h*0.12

        x_tname=x_name+w*0.01
        y_tname=y_name-h*0.08

        xB_IP=leftside+x_name+w_name
        yB_IP=topside
        wb_IP=w*0.29
        hb_IP=h*0.12
        
        xB_tIP=xB_IP+w*0.01
        yB_tIP=yB_IP-h*0.08
        
        xB_port=xB_IP+wb_IP+w*0.02
        yB_port=yB_IP
        wb_port=w*0.17
        hb_port=hb_IP
        
        xB_tport=xB_port+w*0.01
        yB_tport=yB_port-h*0.08
        
        xB_conn=leftside
        yB_conn=yB_IP+hb_IP+h*0.05
        wb_conn=w-rightside-leftside-w*0.4
        hb_conn=h*0.5

        xdiode=xB_conn+wb_conn+w*0.02
        ydiode=yB_conn
        wdiode=w*0.15
        hdiode=hb_conn 
       
        xB_end=xdiode+wdiode+w*0.02
        yB_end=yB_conn
        wb_end=w*0.21
        hb_end=hb_conn

        x_sli=leftside
        y_sli=yB_conn+hb_conn+h*0.1
        w_slide=w-rightside-leftside
        h_slide=h*0.08

        time_start_x=leftside
        time_start_y=y_sli-h*0.08

        time_stop_x=leftside+445
        time_stop_y=time_start_y


        #random name of the client
        #this is here so that the name of clients will be different from the beginning. if the user wants to connect different clients, the clients will most of the time have different names and the user will not have to change them to be able to differentiate them from the other clients.
        possible_initial_names_of_client=["Hubert","Sandrine","Une gaufre","Dark Vador","Chuck Norris","Gandalf","Lucien Typhique","Je n'suis pas un client","Client 404","Rosa","Louis","L'homme invisible","Le Pere Noel","Moise","Nicolas Tesla","Turing","Sherlock Holmes","M. TCP","Jean Valjean","Cosette","Lois Lane","Peter Parker","La Cave","Professeur Chen","Salameche","Nikola Karabatic","Thierry Omeyer","Christophe Pera","Mon grand-pere","Francois Hollande","Roselyne Bachelot","Marine Le Pen","Quentin Tarantino","Un BIM","Une BB","Un INSAlien","Eric Maurincomme","Un brave cheminot","Batman","Un espagnol barbu","Anonymous","JJ Goldman","Goldorak","Pikachu","Le voisin relou","P. Poivre d'Arvor","Morgan Parra","Camille Lopez","Thierry Dussautoir","Un petit caniche","Un bonbon rose","Un rouleau de sopalin","Dany Brillant","Michel Sardou","Super Mario","Sonic","Un projet reseau","Kinder Schokobon","The Lego Movie","La famille Belier","Mon colloc","Un quadra chelou","La foule","Edith Piaf","Pierre et le loup","Parker et Badger","Le lievre et la tortue","Mon ami d'enfance","Mon voisin Totoro","Miyazaki","SlenderMan","Pierre qui roule","Robin des Bois","La chaussette socket","Dobby l'elfe de maison","La Team Socket","Schtroumpf Grognon","Schtroumpf Facreur","Le Nain Bus","Les sept nains","Bilbo le Hobbit","Pierre et Marie Curie","Un breuvage suspect","Un radis odorant","L'autoroute du Sud","La lune","Le superamas Laniakea","Un Japonais presque chauve","Bruce Willis","Le cinquieme element","l'equipe de foot de Norvege","Le petit Spirou","Gaston Lagaffe","M. De Maesmaker","Antigone","Le client inconnu","Ma maman","Frere Tuc","Geany","Emacs","Une indentation foireuse","Une erreur de segmentation","Un client brutal","Un gros burger","L'enigme du jour","The Great Perhaps","La substantifique moelle","Rableais","Gargantua"]
        
        #initial_name_of_client=possible_initial_names_of_client[int(random.random()*len(possible_initial_names_of_client))]
        initial_name_of_client=random.choice(possible_initial_names_of_client)

        #Creation of the elements
        self.btn_conn = wx.Button(self, ID,"Connect",(xB_conn,yB_conn),(wb_conn,hb_conn))
        self.btn_end = wx.Button(self,ID,"Disconnect",(xB_end,yB_end),(wb_end,hb_end))
        self.field_name=wx.TextCtrl(self,ID,initial_name_of_client,(x_name,y_name),(w_name,h_name))
        self.t_name=wx.StaticText(self,ID,"name du client",(x_tname,y_tname))
        self.field_ip=wx.TextCtrl(self,ID,"127.0.0.1",(xB_IP,yB_IP),(wb_IP,hb_IP))
        self.titreip=wx.StaticText(self,ID,"IP adress :",(xB_tIP,yB_tIP))
        self.field_port=wx.TextCtrl(self,ID,"8000",(xB_port,yB_port),(wb_port,hb_port))
        self.titreip=wx.StaticText(self,ID,"Port :",(xB_tport,yB_tport))
        self.slider=wx.Slider(self, ID, value=0, minValue=0, maxValue=100,pos=(x_sli,y_sli), size=(w_slide,h_slide))
        self.diode=wx.ListBox(self,ID,(xdiode,ydiode),(wdiode,hdiode))
        self.time_start=wx.StaticText(self,ID,"00:00",(time_start_x,time_start_y))
        self.time_stop=wx.StaticText(self,ID,"00:00",(time_stop_x,time_stop_y))
        self.timer=wx.Timer(self)
        
        #Creation of colors
        self.background_coulour='#75C8FF'
        self.diode_coulour_connected='#006600'
        self.diode_coulour_disconnected='#666699'
        self.field_coulour='#D6EFFF'
        self.bouton_coulour='#FFD633'
        
        self.field_ip.SetBackgroundColour(self.field_coulour) 
        self.field_port.SetBackgroundColour(self.field_coulour)
        self.field_name.SetBackgroundColour(self.field_coulour)
        self.btn_conn.SetBackgroundColour(self.bouton_coulour) 
        self.SetBackgroundColour(self.background_coulour)
        self.diode.SetBackgroundColour(self.diode_coulour_disconnected)
        
        #Bind of methods and elements
        self.field_name.Bind(wx.EVT_TEXT,self.onfieldname)
        self.btn_conn.Bind(wx.EVT_BUTTON, self.onButtonconn)
        self.btn_end.Bind(wx.EVT_BUTTON,self.onButtonend)
        self.Bind(wx.EVT_TIMER,self.on_timer,self.timer)
        self.Bind(wx.EVT_CLOSE, self.onQuit)
        
        #Disbling some buttons
        self.btn_conn.Enable(True)
        self.btn_end.Enable(False)
        
        #Variable to check if the client has a name before connecting to the server
        self.i_entered_a_name=True
        self.myname="Hubert"

        #creation of the client
        self.CLI=Client(None,self)

    #annex method, to check later if the port entered is an int
    def is_int(self,s):
		try: 
			int(s)
			return True
		except ValueError:
			return False 

    #method which checks if there is something written in the port field
    #called every time the value of port changes
    def onfieldname(self,evt):
        if len(evt.GetEventObject().GetValue())==0:
            i_entered_a_name=True
            self.btn_conn.Enable(False)
        else:
            i_entered_a_name=False
            self.btn_conn.Enable(True)

  
    #connection button
    #checks if the port and ip adress can enable the client to connect to a valid and active server?
    #if not, an error box appears and the user can start again
    #if so, a thread is created to call runClient. The client is then connected.
    def onButtonconn(self, evt) :

        i_am_connected=False #variable which checks if the client connected the server

        ip=self.field_ip.GetValue()
        #client tries to connect with given ip and port
        #checks two things : if something is written in the port and if it manages to connect to a server with this port and this ip
        try:
            port=int(self.field_port.GetValue())
            i_am_connected=self.CLI.connectionToServer(ip,port)
        except ValueError:
            print "You haven't specified a port. Please do."

        #if it did not manage to connect
        if i_am_connected==False:
            wx.MessageBox('Impossible de se connecter au serveur avec ces identifiants. Veuillez : \n -verifier les identifiants \n -verifier que le serveur est bien fonctionnel', 'Impossible de se connecter au serveur..',wx.OK | wx.ICON_INFORMATION) 

        #if connection succedded
        else:
            self.btn_end.Enable(True)
            self.btn_conn.Enable(False)
            self.myname=self.field_name.GetValue()

            #thread for runclient
            thrrun = threading.Thread(target = self.CLI.runClient,args=())
            thrrun.start()

            self.diode.SetBackgroundColour(self.diode_coulour_connected)
   
    #method for button "disconnect"
    #calls client's departure methode
    #the client is then able to connect to the server again, or to another server.
    def onButtonend(self,evt):
		self.CLI.departure(True)
		self.btn_end.Enable(False)
		self.btn_conn.Enable(True)
		self.diode.SetBackgroundColour(self.diode_coulour_disconnected)
                self.timer.Stop()
                self.time_start.SetLabel("00:00")
                self.time_stop.SetLabel("00:00")
                self.slider.SetValue(0)

    #Timer method. Prints how long of the song the user has already heard
    def on_timer(self,timer):
        self.slider.SetMin(0)
        self.slider.SetMax(self.CLI.pgPlayer.get_length())
        self.slider.SetValue(self.CLI.pgPlayer.get_time())
        current_time_s=self.CLI.pgPlayer.get_time()/1000
        remaining_secs_i=current_time_s%60
        minutes_i=(current_time_s-remaining_secs_i)/60
        convert_time_i=str(minutes_i)+":"+str(remaining_secs_i)
        self.time_start.SetLabel(convert_time_i)
        total_time_s=self.CLI.pgPlayer.get_length()/1000
        remaining_secs_f=total_time_s%60
        minutes_f=(total_time_s-remaining_secs_f)/60
        convert_time_f=str(minutes_f) + ":" + str(remaining_secs_f)
        self.time_stop.SetLabel(convert_time_f)

    #method for the X button. Quits application
    def onQuit(self, evt) :
        self.onButtonend(evt)
        self.Destroy()
    


#=========================================================================================================================================
#                                                                     Main
#=========================================================================================================================================


if __name__=="__main__":
	
	window_width=500
	window_height=250
        xpos=700
	ypos=40
	
	app = wx.PySimpleApp()
	app.TopWindow = MainFrame(None,-1,"Stereo BIM ~ Client",(xpos,ypos),(window_width,window_height))
	app.TopWindow.Show()
	app.MainLoop()
